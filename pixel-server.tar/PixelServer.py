import sys
import io
import datetime
import uuid
import logging
import logging.handlers

from flask import Flask, send_file, request, abort

app = Flask(__name__)
PIXEL_IMAGE = open("Cleargif.gif", "rb").read()

log_handler = logging.handlers.WatchedFileHandler('/var/log/pixel-server/logs/pixel.log')
logger = logging.getLogger()
logger.addHandler(log_handler)
logger.setLevel(logging.INFO)


@app.route("/")
def pixel():

    byte_io = io.BytesIO(PIXEL_IMAGE)
    response = send_file(byte_io, mimetype="image/gif")

    user = request.cookies.get("user")
    if user is None:
        user = str(uuid.uuid4())
        response.set_cookie("user", user)

    date = str(datetime.datetime.now())

    log_output = ' '.join([date, user, request.remote_addr, request.headers.get('User-Agent')])

    logging.info(log_output)
    return response


if __name__ == "__main__":
    if len(sys.argv) > 1:
        port = int(sys.argv[1])
    else:
        port = 8080
    app.run(host='0.0.0.0', port=port)
